class SecureMemoryStore:
    def __init__(self, guard):
        self.guard = guard
        self.memories = []
        self.quarantine = []
        self.review = []

    def add(self, content, source="user"):
        result = self.guard.analyze(content, source)

        memory = {
            "content": content,
            "source": source,
            "risk_score": result["score"],
            "findings": result["findings"],
            "action": result["action"]
        }

        if result["action"] == "quarantine":
            self.quarantine.append(memory)
        elif result["action"] == "review":
            self.review.append(memory)
        else:
            self.memories.append(memory)

        return memory

    def get_all(self):
        return self.memories

    def get_quarantine(self):
        return self.quarantine

    def get_review(self):
        return self.review
import re


class InjectionDetector:
    patterns = [
        r"ignore\s+(all\s+)?previous\s+instructions",
        r"disregard\s+(all\s+)?previous",
        r"system\s+instruction",
        r"developer\s+message",
        r"reveal\s+(any\s+)?secret",
        r"from\s+now\s+on",
        r"you\s+are\s+now",
        r"override\s+instructions"
    ]

    def detect(self, content):
        matches = []

        for pattern in self.patterns:
            if re.search(pattern, content, re.IGNORECASE):
                matches.append(pattern)

        return {
            "name": "prompt_injection",
            "score": min(60, len(matches) * 20),
            "matches": matches
        }


class PiiDetector:
    patterns = {
        "email": r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b",
        "phone": r"\b\d{10}\b",
        "card": r"\b(?:\d[ -]*?){13,16}\b"
    }

    def detect(self, content):
        matches = []

        for name, pattern in self.patterns.items():
            if re.search(pattern, content):
                matches.append(name)

        return {
            "name": "sensitive_data",
            "score": min(30, len(matches) * 10),
            "matches": matches
        }


class InstructionDetector:
    patterns = [
        r"do not tell the user",
        r"keep this secret",
        r"never tell anyone",
        r"execute this command",
        r"send this information",
        r"download this file"
    ]

    def detect(self, content):
        matches = []

        for pattern in self.patterns:
            if re.search(pattern, content, re.IGNORECASE):
                matches.append(pattern)

        return {
            "name": "suspicious_instruction",
            "score": min(40, len(matches) * 15),
            "matches": matches
        }
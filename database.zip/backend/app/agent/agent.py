class Agent:
    def __init__(self, memory):
        self.memory = memory

    def remember(self, content):
        self.memory.add(content)

    def build_context(self):
        memories = self.memory.get_all()

        return "\n".join(
            m["content"] for m in memories
        )

    def respond(self, message):
        context = self.build_context()

        return {
            "message": message,
            "memory_context": context
        }